<?php
//Encriptar password con MD5
$password = md5('Venezuel@');
echo "Password is:" .$password;
?>